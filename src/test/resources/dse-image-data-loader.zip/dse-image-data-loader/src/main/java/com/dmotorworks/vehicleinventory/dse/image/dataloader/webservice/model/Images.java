package com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "images")
public class Images implements Serializable {
    
    public Images(){
        
    }
    
    @XmlElement(name = "image")
    public List<Image> list;

    public List<Image> getList() {
        return list;
    }

    public void setList(List<Image> list) {
        this.list = list;
    }

}
