package com.dmotorworks.vehicleinventory.dse.image.dataloader.dao;

import java.net.InetAddress;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import oracle.jdbc.internal.OracleCallableStatement;
import oracle.jdbc.internal.OraclePreparedStatement;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;

import com.dmotorworks.lib.GUID;
import com.dmotorworks.lib.GUIDGenerator;
import com.dmotorworks.vehicleinventory.dse.image.common.util.ImageConstants;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.model.ImageRecord;

/**
 * @author tuhing
 *
 */
public class ImageFileLoadDAO {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(ImageFileLoadDAO.class);
    private static final String CLASS_NAME = ImageFileLoadDAO.class.toString();
    
    
    /*
    private final ThreadLocal<SimpleDateFormat> formatter = new ThreadLocal<SimpleDateFormat>(){
                                                            @Override
                                                            protected SimpleDateFormat initialValue() 
                                                            {
                                                                   // return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:SSS a");
                                                               // return new SimpleDateFormat("EEE MMM d hh:mm:ss z yyyy");
                                                                return new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss:SSS z"); //2013-01-30T09:26:56.856-06:00
                                                            }
                                                    };
    */

   /*
    * Injected from blueprint                                                    
    */
                                                    
    DataSource dataSource;                                                    
    
    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    
    

    /**
     * @param recList
     * @param operationName
     * @return
     * @throws Exception
     */
    public Map<String, String> loadImageData(ArrayList<ImageRecord> recList, String operationName, String sourceName) throws Exception{
        
        log.debug(CLASS_NAME + ": ENTRY : loadImageData()");
    
        Connection connection = getConnection();
        OracleCallableStatement st = (OracleCallableStatement)connection.prepareCall("call DSE.PKG_IMAGE_LOAD.load_image_records(?,?,?,?)");
        Map<String, String> returnGUIDs = new HashMap<String, String>();

        
        try{
            
                oracle.sql.STRUCT [] imageRecAry = new oracle.sql.STRUCT [recList.size()];
                StructDescriptor structDescriptor = StructDescriptor.createDescriptor("DSE.TYP_PHOTO_SETS", connection);
                
                
                ArrayDescriptor stringDescriptor = ArrayDescriptor.createDescriptor("DSE.VARCHAR2S", connection);
                
                
                for (int i = 0; i < recList.size(); i++) {
                    
                     ImageRecord ir = recList.get(i);
                    if(null != ir.getUrlList() && ir.getUrlList().size() > 0)
                    {
                        
                        Object[] imageRecAttributes = new Object[12];

 
                        imageRecAttributes[2] = ir.getDealerID();
                        imageRecAttributes[3] = ir.getStockNum();
                        imageRecAttributes[4] = ir.getVin();
                        imageRecAttributes[5] = this.getSQLDateTime(ir.getLastModifiedDateTime());
                        imageRecAttributes[6] = new java.sql.Timestamp((new java.util.Date()).getTime());
                        imageRecAttributes[10] = new ARRAY(stringDescriptor, connection, ir.getUrlList().toArray());
                        //photo_count
                        imageRecAttributes[11] = ir.getPhotoCount();
                        
                        oracle.sql.STRUCT  struct = new oracle.sql.STRUCT(structDescriptor, connection, imageRecAttributes);
                        imageRecAry[i] = struct;
                    }//if            
                }//for
                
                
                ArrayDescriptor des = ArrayDescriptor.createDescriptor("DSE.TYP_TAB_PHOTO_SETS", connection);
                oracle.sql.ARRAY arrayToPass = new oracle.sql.ARRAY(des, connection, imageRecAry);

                st.setArray(1, arrayToPass);
                st.setString(2, sourceName);
                st.setString(3, operationName);

                st.registerOutParameter(4, Types.ARRAY, "DSE.TYP_TAB_PHOTO_SETS");// TYP_TAB_PHOTO_SETS
                
          
                ((OracleCallableStatement)st).execute();
                                
                
                ARRAY keysArray = st.getARRAY(4);
                if (keysArray != null) 
                {
                    ResultSet rs = keysArray.getResultSet();
                    
                    if(null != rs)
                    while (rs.next()) 
                    {
                        STRUCT outStruct = (STRUCT) rs.getObject(2);
                        GUID imageguid = null;
                        String oper = null;
                        if(null != outStruct){
                            Object[] attributes = outStruct.getAttributes();
                            byte[] guidByte = (byte[])attributes[0];
                            oper = (String)attributes[2];
                            imageguid = GUID.valueOf(guidByte);
                        }else{
                            log.error(CLASS_NAME+" loadImageData() - Returned collection from Stored Procedure is null");
                        }
                        
                        if(null != imageguid)
                        returnGUIDs.put(imageguid.toString(), oper);
                                            
                    }
                }
                
                
                
            }
        
        
        catch(Exception ex)
        {
            log.error("DSE-Image-Load:"+CLASS_NAME+":loadImageData:"+"Exception - "+ex.getMessage());
            throw ex;
        }finally{
            
           st.close();
           DataSourceUtils.releaseConnection(connection, dataSource);
           
           log.debug(CLASS_NAME + ": EXIT : loadImageData()");
            
        }
        
        return returnGUIDs;
    }
    
    
    /**
     * @param operationName
     * @param sourceName
     * @param dealerID
     * @throws Exception
     * Audit log the webservice request
     */
    public void logWebserviceRequest(String operationName, String sourceName, String dealerID) throws Exception
    {
        log.debug(CLASS_NAME + ": ENTRY : logWebserviceRequest()");
        
        final String sql = "INSERT INTO DSE.ESB_SVC_LOG (guid,log_ts,host,event_code,svc_init_guid,route_id,source_id,operation,detail) VALUES (?,?,?,?,?,?,?,?,?)";
        Connection connection = getConnection();
        OraclePreparedStatement  stmt = null;
        
        
        try {
            
            byte[] guidBytes  = GUIDGenerator.generateBytes();
            stmt = (OraclePreparedStatement)connection.prepareStatement(sql);
            stmt.setBytes(1, guidBytes);
            stmt.setTimestamp(2, new Timestamp((new java.util.Date()).getTime()));
            stmt.setString(3, InetAddress.getLocalHost().toString());
            stmt.setString(4, "SVC_INIT_EX" );
            stmt.setBytes(5, guidBytes);
            stmt.setString(6, ImageConstants.ROUTE_SOAP_IMAGE.getValue());
            stmt.setString(7, sourceName );
            stmt.setString(8, operationName);
            stmt.setString(9, "Operation Name:"+operationName+" Source Name:"+sourceName+" Dealer ID:"+dealerID);
            
            stmt.execute();
            
        }
        catch (Exception e) {
            log.error("DSE-Image-Load:"+CLASS_NAME+":logWebserviceRequest:"+"Exception - "+e.getMessage());
            throw e;
        }finally{
            
           try{
            stmt.close();
           }catch(Exception ex){
               //do nothing
           }
           DataSourceUtils.releaseConnection(connection, dataSource);
           
           log.debug(CLASS_NAME + ": EXIT : logWebserviceRequest()");
            
        }
        
    }
    
    
    

    
    /**
     * @param strDate
     * @return
     * @throws Exception
     */
    private java.sql.Timestamp getSQLDateTime(String strDate) throws Exception{
        
        XMLGregorianCalendar xc = DatatypeFactory.newInstance().newXMLGregorianCalendar(strDate);
        java.util.Date convertedDate = xc.toGregorianCalendar().getTime();
        
       
        return new java.sql.Timestamp(convertedDate.getTime());
    }
        


    /**
     * @return
     * @throws SQLException
     */
    private Connection getConnection() throws SQLException {
        if (dataSource == null)
            throw new NullPointerException("DSE-Image-Load:ImageFileLoadDAO:getConnection(): dataSource is null");
        Connection connection = DataSourceUtils.doGetConnection(dataSource);
        if (connection == null)
            throw new NullPointerException("DSE-Image-Load:ImageFileLoadDAO:getConnection(): connection is null");
        return connection;
    }

}
