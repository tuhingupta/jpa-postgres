package com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.interceptor;

import java.net.HttpURLConnection;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.dataloader.service.AuthenticationService;
import com.dmotorworks.vehicleinventory.dse.image.wsdl.AuthenticationHeader;



/**
 * @author tuhing
 *
 */

public class AuthenticationInterceptor extends AbstractPhaseInterceptor<Message> {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(AuthenticationInterceptor.class);
    private static String CLASS_NAME = AuthenticationInterceptor.class.getName();
    
    /*
     * property injected from blueprint
     */
    public AuthenticationService authenticateService;
    
    


    public AuthenticationInterceptor() {
        super(Phase.PRE_INVOKE);
        addBefore(DataValidationInterceptor.class.getName());
    }


    @SuppressWarnings("rawtypes")
    public void handleMessage(Message message) {
       

        boolean isAuthenticated = false;
        
        List msgList = message.getExchange().getInMessage().getContent(List.class);
        
        
        //get the authentication header and validate the source pass
        if(null != msgList)
        {
            for (Iterator iterator = msgList.iterator(); iterator.hasNext();) {
                Object object = (Object) iterator.next();
                 
                if (object instanceof AuthenticationHeader) 
                {
        
                    AuthenticationHeader authHeader = (AuthenticationHeader) object;
                 
                    try {
                            
                            String sourceId = authHeader.getSourceId();
                            String sourcePasswd = authHeader.getSourcePass();
                            
                            if((null != sourceId && ! sourceId.trim().equalsIgnoreCase(""))&&(null != sourcePasswd && ! sourcePasswd.trim().equalsIgnoreCase("")))
                                isAuthenticated = authenticateService.authenticateSource(sourceId, sourcePasswd);

                    }catch (Exception e) {
                        log.error(CLASS_NAME+" AuthenticateService threw exception."+e.getMessage());
                    }
                    
                }
            }//for
        }//if ends
        
        
        //if not authenticated then throw fault message back to caller.        
        if(!isAuthenticated)
            throwFault(message);
        

    }
    
    
    private void throwFault(Message message){
        Fault fault = new Fault(new Exception("Authentication failed"));
        fault.setStatusCode(HttpURLConnection.HTTP_UNAUTHORIZED);
        fault.setFaultCode(new QName("401"));
        message.getInterceptorChain().abort();
        log.error(CLASS_NAME+"401 Authentication Failed : Unauthorized. ");
        throw fault;
    }
    

    public void handleFault(Message messageParam) {
        

    }


    public AuthenticationService getAuthenticateService() {
        return authenticateService;
    }


    public void setAuthenticateService(AuthenticationService authenticateService) {
        this.authenticateService = authenticateService;
    }

    
    

 
    
    
    
/*
 *       //  AuthenticationHeader authHeader = message.getExchange().getInMessage().getContent(AuthenticationHeader.class);
//        exchange.getBindingOperationInfo().getInput().getBindingOperation().get
       // System.out.println("authHeader "+authHeader.getSourcePass());
//        AuthorizationPolicy policy = message.get(AuthorizationPolicy.class);
//        
//        
//        if(policy!=null && policy.getUserName() != null && !("tuhing".equalsIgnoreCase(policy.getUserName().trim())))
//        {
////            Message outMessage = exchange.getOutMessage();
////            outMessage.putAll(exchange.getInMessage());
////            outMessage.put(Message.RESPONSE_CODE, HttpURLConnection.HTTP_UNAUTHORIZED);
//            System.out.println("user name "+policy.getUserName());
//            System.out.println("pwd  "+policy.getPassword());
//         
//         
//        // message.getExchange().setInFaultMessage(outMessage);
//         Fault fault = new Fault(new Exception("Authentication failed"));
//         fault.setStatusCode(HttpURLConnection.HTTP_UNAUTHORIZED);
//         fault.setFaultCode(new QName("401"));
//         message.getInterceptorChain().abort();
//         throw fault;
//        }
//         
//       
        /*
        String userpass = new String(Base64.decodeBase64(exch.getIn().getHeader("Authorization", String.class).getBytes()));
        String[] tokens= userpass.split(":");
        */


     

}    