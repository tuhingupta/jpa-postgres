package com.dmotorworks.vehicleinventory.dse.image.dataloader.dao;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;


import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;


/**
 * @author tuhing
 *
 */
public class AuthenticationDAO {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(AuthenticationDAO.class);
    private static final String CLASS_NAME = AuthenticationDAO.class.toString();
    private final static String AUTHENTICATION_SOURCE_SQL = "SELECT SOURCE_PASSWORD FROM DSE.DATA_SOURCES WHERE SOURCE_ID=? AND SOURCE_PASSWORD=?";

    /*
     * Injected from blueprint                                                    
     */
                                                     
     DataSource dataSource;                                                    
     
     public DataSource getDataSource() {
         return dataSource;
     }

     public void setDataSource(DataSource dataSource) {
         this.dataSource = dataSource;
     }
    
    /**
     * @param sourceID
     * @param sourcePass
     * @return
     * @throws Exception
     */
    public boolean authenticateSource(String sourceID, String sourcePass) throws Exception
    {
        
        log.debug(CLASS_NAME + ": ENTRY : authenticateSource()");
        
        Connection connection = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean isAuthenticated = false;
        String hashedPasswd = null;
        
        try {
            MessageDigest md5Digest = MessageDigest.getInstance("MD5");
            hashedPasswd = javax.xml.bind.DatatypeConverter.printBase64Binary(md5Digest.digest(sourcePass.getBytes()));
        } catch (NoSuchAlgorithmException ex) {
            log.error(CLASS_NAME+" authenticateSource() - Error creating hashed password. ", ex);
            throw ex;
        }
        
        
       try {
            ps = connection.prepareStatement(AUTHENTICATION_SOURCE_SQL);
            ps.setString(1, sourceID);
            ps.setString(2, hashedPasswd);
            rs = ps.executeQuery();
            String returnSrcPass;
            
            
            if (rs.next()) {
                returnSrcPass = rs.getString(1);
                if(null != returnSrcPass && ! returnSrcPass.trim().equals(""))
                    isAuthenticated = true;
            } else {
                log.debug(CLASS_NAME+" authenticateSource could not authenticate source ID / source passwrod - "+ sourceID + " / "+sourcePass);
            }
        } catch (SQLException ex) {
            log.error(CLASS_NAME+" authenticateSourceSource "+ex);
            throw ex;
        } finally{
           
           rs.close(); 
           ps.close();
           DataSourceUtils.releaseConnection(connection, dataSource);
           
           log.debug(CLASS_NAME + ": EXIT : authenticateSource()");
            
        }
       
       return isAuthenticated;

    }

    
    /**
     * @return
     * @throws SQLException
     */
    private Connection getConnection() throws SQLException {
        if (dataSource == null)
            throw new NullPointerException("DSE-Image-Load:AuthenticationDAO:getConnection(): dataSource is null");
        Connection connection = DataSourceUtils.doGetConnection(dataSource);
        if (connection == null)
            throw new NullPointerException("DSE-Image-Load:AuthenticationDAO:getConnection(): connection is null");
        return connection;
    }
    
}
