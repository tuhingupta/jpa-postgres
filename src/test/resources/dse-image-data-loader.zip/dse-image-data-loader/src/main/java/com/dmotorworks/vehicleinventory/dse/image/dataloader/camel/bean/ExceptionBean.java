package com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.bean;

import org.apache.camel.Exchange;
import org.apache.camel.Handler;
import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.common.model.ESBErrorLogBean;
import com.dmotorworks.vehicleinventory.dse.image.common.service.ESBErrorLogService;
import com.dmotorworks.vehicleinventory.dse.image.common.util.ImageConstants;

/**
 * @author tuhing
 *
 */
public class ExceptionBean {

    private static org.slf4j.Logger log = LoggerFactory.getLogger(ExceptionBean.class);
    private final String CLASS_NAME = ExceptionBean.class.getName();
    
    /*
     * inject service from blueprint
     */
    
    public ESBErrorLogService esbErrorLogService;
    


    @Handler   
    public void printingBody(Exchange exch){
    
        log.error("ExceptionBean-Thread- "+Thread.currentThread().getName()+exch.getIn().getBody());
        
        String errorMessage = new String();
        String msgBody = new String();
        String causeMsg = new String();
        
        Exception cause = (Exception)exch.getProperty(Exchange.EXCEPTION_CAUGHT);        
        if(null != cause){
        
            errorMessage = cause.getMessage();
            
            if(null != cause.getCause())
                causeMsg = cause.getCause().toString();
        
        }
        
       
        if(null != exch.getIn().getBody() && exch.getIn().getBody() instanceof java.lang.String){
            msgBody = (String)exch.getIn().getBody();
            
            if(msgBody.length() > 3000){
                msgBody = msgBody.substring(0, 2999);
            }
        }//if 
       else{
           msgBody = exch.getIn().getBody().toString();
       }
        
       
      logError(exch.getFromRouteId(), (String) exch.getIn().getHeader(ImageConstants.OPERATION_NAME.getValue()), errorMessage, (String) exch.getIn().getHeader(ImageConstants.SOURCE_NAME.getValue()), msgBody, causeMsg );
        
   
    }
    
    
    /**
     * @param routeDesc
     * @param operationName
     * @param errorMsg
     * @param sourceName
     * @throws Exception
     */
    private void logError(String routeDesc, String operationName, String errorMsg, String sourceName, String messageBody, String causeMsg) 
    {
        
        ESBErrorLogBean errorLogBean = new ESBErrorLogBean();
        errorLogBean.setRouteDesc(routeDesc);
        errorLogBean.setOperationName(operationName);
        errorLogBean.setExceptionMsg(errorMsg);
        errorLogBean.setProcessName(sourceName);
        errorLogBean.setMsgBody(messageBody);
        errorLogBean.setDescription(causeMsg);
        
        try{
            esbErrorLogService.logError(errorLogBean);
        }catch(Exception ex){
            log.error(CLASS_NAME + ":logError: Exception in logging error - "+ex.toString());
        }
        
    }
    
    
    
    
    public ESBErrorLogService getEsbErrorLogService() {
        return esbErrorLogService;
    }




    public void setEsbErrorLogService(ESBErrorLogService esbErrorLogService) {
        this.esbErrorLogService = esbErrorLogService;
    }


}
