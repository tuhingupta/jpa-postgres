package com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "image")
public class Image implements Serializable{
    
    
    protected String dealerId;
    protected String stockNum;
    protected String vin;
    protected String photoURLs; 
    protected String dateModified;
    
    public Image() {
        // TODO Auto-generated constructor stub
    }
    
    
    public Image(String dealerId, String stockNum, String vin, String photoURLs, String dateModified ) {

        this.dealerId = dealerId;
        this.stockNum = stockNum;
        this.vin = vin;
        this.photoURLs = photoURLs; 
        this.dateModified = dateModified;
        
    }
    
    
    
    public String getDealerId() {
        return dealerId;
    }


    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }


    public String getStockNum() {
        return stockNum;
    }


    public void setStockNum(String stockNum) {
        this.stockNum = stockNum;
    }


    public String getVin() {
        return vin;
    }


    public void setVin(String vin) {
        this.vin = vin;
    }


    public String getPhotoURLs() {
        return photoURLs;
    }


    public void setPhotoURLs(String photoURLs) {
        this.photoURLs = photoURLs;
    }


    public String getDateModified() {
        return dateModified;
    }


    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }
    
    
    
    

}
