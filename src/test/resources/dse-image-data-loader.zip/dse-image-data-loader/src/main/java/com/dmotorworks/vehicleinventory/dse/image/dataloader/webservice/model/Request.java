package com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "request")
public class Request implements Serializable {

    @XmlElement(name = "sourceName")
    protected String sourceName;
    
    @XmlElement(name = "requestTimestamp")
    protected String requestTimestamp;
    
    @XmlElement(name = "images")
    protected Images images;
    
    
    public String getSourceName() {
        return sourceName;
    }
    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }
    public String getRequestTimestamp() {
        return requestTimestamp;
    }
    public void setRequestTimestamp(String requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }
    public Images getImages() {
        return images;
    }
    public void setImages(Images images) {
        this.images = images;
    }
    
    
    
}
