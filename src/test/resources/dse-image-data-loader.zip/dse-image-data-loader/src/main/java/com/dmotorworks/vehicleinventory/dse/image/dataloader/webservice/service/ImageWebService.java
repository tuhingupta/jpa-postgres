package com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.model.Request;
/*
 * for rest ws - NOT USED CURRENTLY. FOR FUTURE USE
 */
        
@Path("/images")
public class ImageWebService {
    
    
    public ImageWebService() {
        // TODO Auto-generated constructor stub
    }
    
    
    @POST
    @Path("/")
    @Consumes("application/vnd.dse-v2+xml")
    @Produces("application/xml")
    public Response addImages(Request request) {
        System.out.println("----invoking addImages ");
//        customer.setId(++currentId);
//
//        customers.put(customer.getId(), customer);

        System.out.println("service call over");
        return Response.ok().entity(request).build();
    }

}
