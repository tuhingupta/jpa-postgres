package com.dmotorworks.vehicleinventory.dse.image.dataloader.webservice.interceptor;

import java.net.HttpURLConnection;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.common.service.ImageFieldValidationService;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.serviceimpl.ImageFileLoadServiceImpl;
import com.dmotorworks.vehicleinventory.dse.image.wsdl.AuthenticationHeader;
import com.dmotorworks.vehicleinventory.dse.image.wsdl.ImageSet;



/**
 * @author tuhing
 *
 */
public class DataValidationInterceptor extends AbstractPhaseInterceptor<Message> {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(DataValidationInterceptor.class);
    private static String CLASS_NAME = DataValidationInterceptor.class.getName();
    
    public ImageFieldValidationService imageFieldValidationService;

    public ImageFieldValidationService getImageFieldValidationService() {
        return imageFieldValidationService;
    }

    public void setImageFieldValidationService(ImageFieldValidationService imageFieldValidationService) {
        this.imageFieldValidationService = imageFieldValidationService;
    }

    public DataValidationInterceptor() {
        super(Phase.PRE_INVOKE);
    }

    
    
    /* (non-Javadoc)
     * @see org.apache.cxf.interceptor.Interceptor#handleMessage(org.apache.cxf.message.Message)
     */
    @SuppressWarnings("unchecked")
    public void handleMessage(Message message) {
       
        boolean valid = true;
        String errorMessage = new String();
       
       
      List list = message.getExchange().getInMessage().getContent(List.class);
       if(null != list && list.size()>0){
       
         //  String sourceID = (String)list.get(0);
//           String dealerID = (String)list.get(2);
//           List<ImageSet> listSet = (List<ImageSet>)list.get(3);
           
           String dealerID = (String)list.get(1);
           List<ImageSet> listSet = (List)list.get(2);
           
           log.debug("Data Validation Interceptor Dealer ID is "+ dealerID);
           
           
           //if there are no image sets then data check failed
           if(null == listSet || listSet.size()==0)
           {
               log.debug("Data Validation Interceptor Image List size is "+ listSet.size());
               valid = false;
           }

           
           //check if source or the dealer is null and throw a fault
           if(!(imageFieldValidationService.isDealerIDValid(dealerID))) // && imageFieldValidationService.isSourceIDValid(sourceID)))
           {
               valid = false;
               
           }

                      
       }
       
       if(!valid){
           Fault fault = new Fault(new Exception("The server does not meet one of the preconditions that the requester put on the request. "));
           fault.setStatusCode(HttpURLConnection.HTTP_PRECON_FAILED);
           fault.setFaultCode(new QName("412 Precondition Failed : The server does not meet one of the preconditions that the requester put on the request. "));
           message.getInterceptorChain().abort();
           log.error(CLASS_NAME+"412 Precondition Failed : The server does not meet one of the preconditions that the requester put on the request. ");
           throw fault;
       }
       
       
    }
    

    

    public void handleFault(Message messageParam) {
        
    
    }
 


     

}    