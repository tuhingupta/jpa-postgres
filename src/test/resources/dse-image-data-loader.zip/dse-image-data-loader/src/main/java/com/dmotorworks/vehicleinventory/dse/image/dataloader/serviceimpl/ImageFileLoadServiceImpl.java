package com.dmotorworks.vehicleinventory.dse.image.dataloader.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.common.service.ImageFieldValidationService;
import com.dmotorworks.vehicleinventory.dse.image.common.util.ImageUtils;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.dao.ImageFileLoadDAO;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.model.ImageRecord;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.service.ImageFileLoadService;


/**
 * @author tuhing
 *
 */
public class ImageFileLoadServiceImpl extends ImageFileLoadService {

    private static org.slf4j.Logger log = LoggerFactory.getLogger(ImageFileLoadServiceImpl.class);
    private static final String CLASS_NAME = ImageFileLoadServiceImpl.class.getName();
    
    public ImageFileLoadDAO imageLoadDAO;
    public ImageFieldValidationService imageFieldValidationService;
    
    
    public ImageFieldValidationService getImageFieldValidationService() {
        return imageFieldValidationService;
    }

    public void setImageFieldValidationService(ImageFieldValidationService imageFieldValidationService) {
        this.imageFieldValidationService = imageFieldValidationService;
    }

    public ImageFileLoadDAO getImageLoadDAO() {
        return imageLoadDAO;
    }

    public void setImageLoadDAO(ImageFileLoadDAO imageLoadDAO) {
        this.imageLoadDAO = imageLoadDAO;
    }
    
    

    /* (non-Javadoc)
     * @see com.dmotorworks.vehicleinventory.dse.image.dataloader.common.service.ImageFileLoadService#saveImageData(java.util.ArrayList, java.lang.String)
     */
    @Override
    public  Map<String, String> saveImageData(ArrayList<ImageRecord> recordList, String operationName, String sourceName) throws Exception {
        // 
        
        log.debug(ImageFileLoadServiceImpl.class.getName() + ": ENTRY : saveImageData()");
        
        ArrayList<ImageRecord> loadList = new ArrayList<ImageRecord>();
        Map<String, String> returnGUIDs = new HashMap<String, String>();
        String dealerID = new String();
        
        if(null != recordList && recordList.size() > 0){
            dealerID = recordList.get(0).getDealerID();
        }
        //log webservice request in DSE.ESB_SVC_LOG        
        if("IMAGE_WEB_SERVICE".equals(operationName)){
        
            imageLoadDAO.logWebserviceRequest(operationName, sourceName, dealerID);
        }
        
        
        //check if photos present, then add to new list
        for (Iterator iterator = recordList.iterator(); iterator.hasNext();) 
        {
            ImageRecord imageRecord = (ImageRecord) iterator.next();
            int urlListSize = imageRecord.getUrlList().size();
            
           if(urlListSize>0 && imageFieldValidationService.isVinOrStockNumValid(imageRecord.getVin(), imageRecord.getStockNum())) 
           {
                imageRecord.setPhotoCount(urlListSize);//store the photo count 
                loadList.add(imageRecord);
           }else
           {
               log.error(CLASS_NAME+" saveImageData() "+"VALIDATION FAILED: OPERATION - "+operationName+ "SOURCE NAME - "+sourceName+" -- RECORD WITH VIN="+imageRecord.getVin()+" AND STOCK NUM ="+imageRecord.getStockNum()+" dropped.");
           }
            
        }
        
        
        if(loadList.size() > 0){
            returnGUIDs = imageLoadDAO.loadImageData(loadList, operationName, sourceName);
        }
        
        log.debug(ImageFileLoadServiceImpl.class.getName() + ": EXIT : saveImageData()");
        
        return returnGUIDs;

    }
}
