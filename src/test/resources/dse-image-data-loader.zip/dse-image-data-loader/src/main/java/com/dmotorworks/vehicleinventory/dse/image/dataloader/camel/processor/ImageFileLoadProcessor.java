package com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.processor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.api.management.ManagedAttribute;
import org.apache.camel.api.management.ManagedResource;
import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.common.util.ImageConstants;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.service.ImageFileLoadService;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.serviceimpl.ImageFileLoadServiceImpl;
//com.dmotorworks.vehicleinventory.dse.image.dataloader.common.camel.processor.ImageFileLoadProcessor
@ManagedResource(description = "Image Load File Processor")
public class ImageFileLoadProcessor implements Processor {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(ImageFileLoadProcessor.class);
    
    private final static String CLASS_NAME = ImageFileLoadProcessor.class.toString();
    
    ImageFileLoadService  imageFileLoadService;
    private static AtomicInteger processorCount = new AtomicInteger(0);
    private static AtomicInteger recordCount = new AtomicInteger(0);
    private static AtomicInteger recordInsertCount = new AtomicInteger(0);
    private static AtomicInteger recordUpdateCount = new AtomicInteger(0);
    private static AtomicInteger recordExceptionCount = new AtomicInteger(0);
    
    
    @ManagedAttribute 
    public static AtomicInteger getRecordInsertCount() {
        return recordInsertCount;
    }

    public static void setRecordInsertCount(AtomicInteger recordInsertCount) {
        ImageFileLoadProcessor.recordInsertCount = recordInsertCount;
    }

    
    @ManagedAttribute 
    public static AtomicInteger getRecordUpdateCount() {
        return recordUpdateCount;
    }

    public static void setRecordUpdateCount(AtomicInteger recordUpdateCount) {
        ImageFileLoadProcessor.recordUpdateCount = recordUpdateCount;
    }

    @ManagedAttribute 
    public static AtomicInteger getRecordExceptionCount() {
        return recordExceptionCount;
    }

    public static void setRecordExceptionCount(AtomicInteger recordExceptionCount) {
        ImageFileLoadProcessor.recordExceptionCount = recordExceptionCount;
    }

    @ManagedAttribute 
    public static AtomicInteger getRecordCount() {
        return recordCount;
    }

    public static void setRecordCount(AtomicInteger recordCount) {
        ImageFileLoadProcessor.recordCount = recordCount;
    }

    public ImageFileLoadService getImageFileLoadService() {
        return imageFileLoadService;
    }

    @ManagedAttribute 
    public static AtomicInteger getProcessorCount() {
        return processorCount;
    }

    public static void setProcessorCount(AtomicInteger processorCount) {
        ImageFileLoadProcessor.processorCount = processorCount;
    }

    public void setImageFileLoadService(ImageFileLoadService imageFileLoadService) {
        this.imageFileLoadService = imageFileLoadService;
    }

    
    
    
    /* (non-Javadoc)
     * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
     */
    public void process(Exchange exchange) throws Exception{
    
        log.debug(CLASS_NAME + ": ENTRY : process()");
        
        final String METHOD_NAME = "process";

        ArrayList arylist = exchange.getIn().getBody(ArrayList.class);
        ArrayList returnList = new ArrayList<String>();
        int listSize = arylist.size();
        
        String operationName = (String)exchange.getIn().getHeader(ImageConstants.OPERATION_NAME.getValue());
        String sourceName = (String)exchange.getIn().getHeader(ImageConstants.SOURCE_NAME.getValue());
        
        
        
        if(null == operationName)
                throw new Exception("DSE-Image-Load:ImageFileLoadProcessor:process: operationName is null. ");
        
       // log.debug(CLASS_NAME+":"+METHOD_NAME+" - "+Thread.currentThread().getName() +" - "+listSize);
       // recordCount.addAndGet(listSize);
        processorCount.incrementAndGet();
        
        Map<String, String> returnGUIDs;
        try {
            returnGUIDs = imageFileLoadService.saveImageData(arylist, operationName, sourceName);
        }
        catch (Exception e) {
            log.debug(CLASS_NAME + ": EXCEPTION  : process() : "+e.getMessage());
            recordExceptionCount.incrementAndGet();
            throw e;
        }
        
        if(null != returnGUIDs){
            
            recordCount.addAndGet(returnGUIDs.size());
            
            Iterator it = returnGUIDs.entrySet().iterator();
            while (it.hasNext()) {
                
                Map.Entry<String, String> pairs = (Map.Entry)it.next();
                returnList.add(pairs.getKey());
           //     log.debug(pairs.getKey()+"-"+pairs.getValue());
                if("I".equalsIgnoreCase(pairs.getValue())){
                    recordInsertCount.incrementAndGet();
                } else if("U".equalsIgnoreCase(pairs.getValue())){
                    recordUpdateCount.incrementAndGet();
                }
                
            }//while
            
        }//if
        
         //set property values for operation and source name codes
       
         exchange.getOut().setBody(returnList);
         exchange.getOut().setHeader(ImageConstants.OPERATION_NAME.getValue(), operationName);
         exchange.getOut().setHeader(ImageConstants.SOURCE_NAME.getValue(), sourceName);
        
        log.debug(CLASS_NAME + ": EXIT : process()");
        
    }

}
