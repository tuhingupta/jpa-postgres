package com.dmotorworks.vehicleinventory.dse.image.dataloader.service;

public interface AuthenticationService {

    public boolean authenticateSource(String sourceID, String sourcePass) throws Exception;
}
