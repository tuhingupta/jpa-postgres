package com.dmotorworks.vehicleinventory.dse.image.dataloader.service;

import java.util.ArrayList;
import java.util.Map;

import com.dmotorworks.vehicleinventory.dse.image.dataloader.model.ImageRecord;

public abstract class ImageFileLoadService {

    
   public abstract  Map<String, String> saveImageData(ArrayList<ImageRecord> recordList, String operationName, String sourceName) throws Exception;
    
   

}
