package com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.bean;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;
import java.lang.management.MemoryUsage;
import java.util.Arrays;
import java.util.Iterator;

import org.apache.camel.Exchange;
import org.apache.camel.Handler;
import org.slf4j.LoggerFactory;


public class OutOfMemoryPrintBean {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(OutOfMemoryPrintBean.class);
    
    @Handler   
    public void printingMemoryStats(Exchange exch){
    
            Iterator iter = ManagementFactory.getMemoryPoolMXBeans().iterator();


            log.debug("OutOfMemoryPrintBean-Thread- "+Thread.currentThread().getName()+exch.getIn().getBody());
            
            while (iter.hasNext())
            {
                MemoryPoolMXBean item = (MemoryPoolMXBean) iter.next();
               
                String name = item.getName();
                MemoryType type = item.getType();
                MemoryUsage usage = item.getUsage();
                MemoryUsage peak = item.getPeakUsage();
                MemoryUsage collections = item.getCollectionUsage();
                
                log.debug(Arrays.toString(item.getMemoryManagerNames())+" - "+"Type "+type.toString() +" Usage:- used "+usage.getUsed() + " Max "+usage.getMax()+" Peak used "+peak.getUsed() + " peak Max "+peak.getMax());
                          
            }
   
    }

}
