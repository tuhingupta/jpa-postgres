package com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.routes;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.beanio.BeanIODataFormat;
import org.apache.camel.spi.DataFormat;
import org.apache.cxf.message.MessageContentsList;
import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.common.util.ImageConstants;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.model.ImageRecord;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.service.ImageFileLoadService;
import com.dmotorworks.vehicleinventory.dse.image.wsdl.AuthenticationHeader;
import com.dmotorworks.vehicleinventory.dse.image.wsdl.ImageSet;
import com.dmotorworks.vehicleinventory.dse.image.wsdl.PhotoURLs;


/**
 * @author tuhing
 * 
 */

public class ImageWSRouteBuilder extends RouteBuilder {
    
    private static org.slf4j.Logger log = LoggerFactory.getLogger(ImageWSRouteBuilder.class);
    private static String CLASS_NAME = ImageWSRouteBuilder.class.getName();
    private static String REOUTE_READ_QUEUE = "dse-image.ROUTE_READ_QUEUE-REAL_TIME_IMAGE_DATA";
    
    DataFormat format = new BeanIODataFormat("classpath:beanio/ImageFileCSVToJava.xml", "imageFile");
    
    /*
     * injected from blueprint
     */
    ImageFileLoadService imageFileLoadService;
    String publishedServerEndpoint;



    
    @Override
    public void configure()  {


      onException(Exception.class)
        .handled(true)
        .beanRef("exceptionBean")
        .to("log:" + CLASS_NAME + exceptionMessage() +"?level=ERROR&showAll=true")
      .end();
        
      
      //cxf endpoint to receive SOAP request for image webservice
      from("cxf:bean:imageRealTime?dataFormat=POJO")
            .routeId(ImageConstants.ROUTE_SOAP_IMAGE.getValue())
            .inOnly(("activemq:queue:REAL_TIME_IMAGE_DATA"))
            .process(sendRSResponse())//send OK response back to caller
            .end()
        ;
        
      //process the message
      from("activemq:queue:REAL_TIME_IMAGE_DATA"+"?concurrentConsumers="+getQueueConcurrentConsumers())
          .routeId(REOUTE_READ_QUEUE)
            .setHeader("OPERATION_NAME", constant("IMAGE_WEB_SERVICE"))
         .transacted()
            .process(processMessage())
         .end()
        .inOnly("activemq:queue:PROCESS_IMAGE_DATA")
      .end()
      ;
        

    }
    
    /**
     * @return
     */
    Processor sendRSResponse() {
        
        return new Processor() {
            
            /* (non-Javadoc)
             * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
             */
            public void process(Exchange exchange) throws Exception {
             
                //no check is performed here. Incase the request has passed
                //authentication and data validation interceptors then OK message is sent back to the caller.
                //our processing continues after that.
                exchange.getOut().setBody("OK");
            } 
               
        };
    }
    
    
     /**
     * @return
     */
    Processor processMessage() {
            
            return new Processor() {
                
                /* (non-Javadoc)
                 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
                 */
                public void process(Exchange exchange) throws Exception {
                 
                    MessageContentsList result = (MessageContentsList)exchange.getIn().getBody();
                    String operationName = (String)exchange.getIn().getHeader(ImageConstants.OPERATION_NAME.getValue());
                
                    String dealer = (String)result.get(1);
                    List<ImageSet> imageSetList = (List)result.get(2);
                    AuthenticationHeader  authHeader = (AuthenticationHeader) result.get(3);
                    String sourceName = authHeader.getSourceId();
                                    
                    ArrayList returnList = new ArrayList<String>();
                    Map<String, String> returnGUIDs = null;
                    
                    ArrayList<ImageRecord> irList = new ArrayList<ImageRecord>();
                    
                    for (Iterator iterator = imageSetList.iterator(); iterator.hasNext();) 
                    {
                      ImageSet imageSet = (ImageSet) iterator.next();

                      if(null != imageSet)
                      {
                          ImageRecord ir = new ImageRecord();
                          ir.setSourceID(sourceName);
                          ir.setDealerID(dealer);
                          ir.setVin(imageSet.getVin());
                          ir.setStockNum(imageSet.getStockNum());
                          ir.setLastModifiedDateTime(imageSet.getLastModifiedDate().toString());
                          
                          //only set following if photo urls are present
                          if(null != imageSet.getPhotoURLs() && null != imageSet.getPhotoURLs().getPhotoURL()){
                              ir.setPhotoUrls(this.getPhotoURLs(imageSet.getPhotoURLs()));
                              ir.setUrlList((ArrayList)imageSet.getPhotoURLs().getPhotoURL() );
                          }
                          
                          irList.add(ir);
                      }  
                      
                    }//for
                    
                    
                    try {
                    
                        if(irList.size() > 0){
                            returnGUIDs = imageFileLoadService.saveImageData(irList, operationName, sourceName);
                        }
                    }
                    catch (Exception e) {
                        log.error(CLASS_NAME + ": EXCEPTION  : process() : "+e.getMessage());
                       

                        throw e;
                    }
                    
                    
                    if(null != returnGUIDs){                        
                                              
                        Iterator it = returnGUIDs.entrySet().iterator();
                       
                        while (it.hasNext()) {
                            
                            Map.Entry<String, String> pairs = (Map.Entry)it.next();
                            returnList.add(pairs.getKey());
                    
                            /* FOLLOWING COMMENTED CODE NEEDS TO BE USED INCASE WE NEED TO COLLECT METRICS FOR INSERT/UPDATE
                            if("I".equalsIgnoreCase(pairs.getValue())){
                      
                            } else if("U".equalsIgnoreCase(pairs.getValue())){
                      
                            }*/
                            
                        }//while
                        
                    }//if
                    
                  //set property values for operation and source name codes
                    
                    exchange.getOut().setBody(returnList);
                    exchange.getOut().setHeader(ImageConstants.OPERATION_NAME.getValue(), operationName);
                    exchange.getOut().setHeader(ImageConstants.SOURCE_NAME.getValue(), sourceName);
                    

                } 
                
                
        /**
         * @param photoURLs
         * @return
         */
        public String getPhotoURLs(PhotoURLs photoURLs){
            
            String photoURL = new String();
            
            ArrayList<String> urlList = (ArrayList<String>) photoURLs.getPhotoURL();
            
            if(null != urlList){
                
                for (Iterator iterator = urlList.iterator(); iterator.hasNext();) {
                    photoURL += (String) iterator.next()+"|";
                    
                }//for end
                
                if(null != photoURL && photoURL.length() > 0){
                    photoURL = photoURL.substring(0, photoURL.length()-1);
                }
                
                
            }
            
            
            return photoURL;
        }
                
        
           
        };
    }
    
    
    /**
     * @param appName
     * @return
     */
    private String getEndpointUrl(String appName) {
        String endpointUrl = "";
        if (publishedServerEndpoint != null) {
            StringBuilder endpointPrefix = new StringBuilder("&publishedEndpointUrl=");
            endpointPrefix.append(publishedServerEndpoint);
            if (!publishedServerEndpoint.endsWith("/")) {
                endpointPrefix.append('/');
            }
            endpointPrefix.append("cxf/dmi/webservices/").append(appName);
            endpointUrl = endpointPrefix.toString();
        }
        return endpointUrl;
    }
    
    
    public String getPublishedServerEndpoint() {
        return publishedServerEndpoint;
    }

    public void setPublishedServerEndpoint(String publishedServerEndpoint) {
        this.publishedServerEndpoint = publishedServerEndpoint;
    }

    public ImageFileLoadService getImageFileLoadService() {
        return imageFileLoadService;
    }

    public void setImageFileLoadService(ImageFileLoadService imageFileLoadService) {
        this.imageFileLoadService = imageFileLoadService;
    }
    
    //queue concurrent consumer injected from blueprint
    public String queueConcurrentConsumers;    

    public String getQueueConcurrentConsumers() {
        return queueConcurrentConsumers;
    }

   public void setQueueConcurrentConsumers(String queueConcurrentConsumers) {
        this.queueConcurrentConsumers = queueConcurrentConsumers;
    }
     
     
    
    /*
     * to be removed later
     */
    

     
     
     
     /**
      * rs webservice call
      
     
     //TO DO: need to do authentication of web service before processing -- http basic auth required
     
     from("cxfrs://bean://rsServer")
         .inOnly(("activemq:queue:REAL_TIME_IMAGE_DATA"))
         .process(sendRSResponse())
         .stop()
     ;
     
     
     from("activemq:queue:REAL_TIME_IMAGE_DATA"+getQueueSettings())
         .setHeader("OPERATION_NAME", constant("IMAGE_WEB_SERVICE"))
         .setHeader("SOURCE_NAME", constant("DS"))
         .unmarshal(format)
         .bean(ExceptionBean.class)
         .processRef("imageFileLoadProcessor")
         .inOnly("activemq:queue:PROCESS_IMAGE_DATA")
       .end()
       ;
     
     
     from("cxfrs://bean://rsImageServer")
     //.process("authenticate??")
     //.multicast().parallelProcessing().
     .to("direct:sendRTResponse")
     .end();
     
     
     from("direct:sendRTResponse")
     .process(sendRSResponse())
     .end();
     
     
     from("direct:processRTMessage")
     //    .process(processor)
         .inOnly(("activemq:queue:RT_IMAGE_DATA"))
     .end()
 ; 
*/

}
