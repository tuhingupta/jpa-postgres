package com.dmotorworks.vehicleinventory.dse.image.dataloader.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dmotorworks.vehicleinventory.dse.image.common.util.URLValidation;

/**
 * @author tuhing
 *
 */
public class ImageRecord {
    
    private String dealerID;
    private String vin;
    private String stockNum;
    private String photoUrls;
    private String lastModifiedDateTime;
    private String sourceID;
    private int photoCount;
    private List<String> urlList = new ArrayList<String>();
    
    
    
    public int getPhotoCount() {
        return photoCount;
    }

    public void setPhotoCount(int photoCount) {
        this.photoCount = photoCount;
    }

    public String getSourceID() {
        return sourceID;
    }

    public void setSourceID(String sourceID) {
        this.sourceID = sourceID;
    }
    
    public List<String> getUrlList() {
        
        if(urlList.size() == 0 && null != photoUrls && photoUrls.length() > 0)
        {
            return URLValidation.validateURL(photoUrls.split("\\|"));
            
        }
        
        return urlList;
    }
    
    public void setUrlList(ArrayList<String> urlList) {
        this.urlList = urlList;
    }
    
    public String getDealerID() {
        return dealerID;
    }
    public void setDealerID(String dealerID) {
        this.dealerID = dealerID;
    }
    public String getVin() {
        return vin;
    }
    public void setVin(String vin) {
        this.vin = vin;
    }
  
    public String getPhotoUrls() {
        
        if(urlList.size() == 0 && null != photoUrls && photoUrls.length() > 0){
            
            String [] urlAry = photoUrls.split("\\|");
            urlList = Arrays.asList(urlAry);
            
        }
        
        return photoUrls;
    }
    public void setPhotoUrls(String photoUrls) {
        this.photoUrls = photoUrls;
        if(urlList.size() == 0 && null != photoUrls && photoUrls.length() > 0){
            
            String [] urlAry = photoUrls.split("\\|");
            urlList = Arrays.asList(urlAry);
            
        }
    }
   

    
    public String getStockNum() {
        return stockNum;
    }

    public void setStockNum(String stockNum) {
        this.stockNum = stockNum;
    }

    public String getLastModifiedDateTime() {
        return lastModifiedDateTime;
    }

    public void setLastModifiedDateTime(String lastModifiedDateTime) {
        this.lastModifiedDateTime = lastModifiedDateTime;
    }

    //test main method
    public static void main(String[] args) {
        
        ImageRecord ir = new ImageRecord();
        ir.setPhotoUrls("http://cdn.getauto.com/photos/1/187501/1c/1G4GB5E33CF218892-1c.jpg|http://cdn.getauto.com/photos/1/187501/2c/1G4GB5E33CF218892-2c.jpg|http://cdn.getauto.com/photos/1/187501/3c/1G4GB5E33CF218892-3c.jpg|http://cdn.getauto.com/photos/1/187501/4c/1G4GB5E33CF218892-4c.jpg|http://cdn.getauto.com/photos/1/187501/5c/1G4GB5E33CF218892-5c.jpg|http://cdn.getauto.com/photos/1/187501/6c/1G4GB5E33CF218892-6c.jpg|http://cdn.getauto.com/photos/1/187501/7c/1G4GB5E33CF218892-7c.jpg|http://cdn.getauto.com/photos/1/187501/8c/1G4GB5E33CF218892-8c.jpg|http://cdn.getauto.com/photos/1/187501/9c/1G4GB5E33CF218892-9c.jpg|http://cdn.getauto.com/photos/1/187501/10c/1G4GB5E33CF218892-10c.jpg");
        System.out.println(ir.getUrlList().size());
    }

}
