package com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.beanio.BeanIODataFormat;
import org.apache.camel.spi.DataFormat;







/**
 * @author tuhing
 *
 */
public class ImageFileLoadRouteBuilder extends RouteBuilder {

    private final String CLASS_NAME = ImageFileLoadRouteBuilder.class.getName();
    
    /*
     * properties injected into bean
     */
    
    
    public String prefixFileName;
    public String baseErrorDir;
    
    


    //BeanIODataFormat - to be replaced by camel-beanio when we upgrade to camel 2.10
    DataFormat format = new BeanIODataFormat("classpath:beanio/ImageFileCSVToJava.xml", "imageFile");
    DataFormat newFormat = new BeanIODataFormat("classpath:beanio/JavaToCSV.xml", "newimageFile");
    
    private static String PROCESS_MESSAGES = "PROCESS_MESSAGES";

    
    
    
    /*
     * (non-Javadoc)
     * @see org.apache.camel.builder.RouteBuilder#configure()
     * 
     * This route reads the messages from the queue and loads the data in the messages to DB.
     * Once data is loaded it is sent to activemq:queue:PROCESS_IMAGE_DATA queue for downloading the images.
     */
    
    @SuppressWarnings("restriction")
    @Override
    public void configure() throws Exception {
        

          
          from("activemq:queue:LOAD_FILE_DATA"+"?concurrentConsumers="+getQueueConcurrentConsumers())
               .onException(Throwable.class)
                   .logStackTrace(true)
                   .to("log:" + CLASS_NAME + exceptionMessage() +"?level=ERROR&showAll=true")
                   .beanRef("exceptionBean")
                   .handled(true)
              .end()
              .transacted("PROPAGATION_REQUIRES_NEW")
                  .routeId(PROCESS_MESSAGES)
                  .unmarshal(format)
                  .processRef("imageFileLoadProcessor")
              .end()
              .inOnly("activemq:queue:PROCESS_IMAGE_DATA")
                      .setHeader("OPERATION_NAME", simple("${header.OPERATION_NAME}"))
                      .setHeader("SOURCE_NAME", simple("${header.SOURCE_NAME}"))
              .end()
              ;
          
    }
    


    public String getPrefixFileName() {
        return prefixFileName;
    }

    public void setPrefixFileName(String prefixFileName) {
        this.prefixFileName = prefixFileName;
    }
    

    public String getBaseErrorDir() {
        return baseErrorDir;
    }




    public void setBaseErrorDir(String baseErrorDir) {
        this.baseErrorDir = baseErrorDir;
    }
    
    
    //queue concurrent consumer injected from blueprint
    public String queueConcurrentConsumers;    

    public String getQueueConcurrentConsumers() {
        return queueConcurrentConsumers;
    }

   public void setQueueConcurrentConsumers(String queueConcurrentConsumers) {
        this.queueConcurrentConsumers = queueConcurrentConsumers;
    }

}
