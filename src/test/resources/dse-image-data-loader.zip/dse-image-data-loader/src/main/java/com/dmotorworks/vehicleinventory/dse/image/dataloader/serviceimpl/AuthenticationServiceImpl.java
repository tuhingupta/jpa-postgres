package com.dmotorworks.vehicleinventory.dse.image.dataloader.serviceimpl;

import org.slf4j.LoggerFactory;

import com.dmotorworks.vehicleinventory.dse.image.dataloader.dao.AuthenticationDAO;
import com.dmotorworks.vehicleinventory.dse.image.dataloader.service.AuthenticationService;

/**
 * @author tuhing
 *
 */
public class AuthenticationServiceImpl implements AuthenticationService{

    private static org.slf4j.Logger log = LoggerFactory.getLogger(AuthenticationServiceImpl.class);
    private static final String CLASS_NAME = AuthenticationServiceImpl.class.toString();

    /*
     * injected from Blueprint
     */
    
    public AuthenticationDAO authenticationDAO;
    
    public AuthenticationDAO getAuthenticationDAO() {
        return authenticationDAO;
    }
    public void setAuthenticationDAO(AuthenticationDAO authenticationDAO) {
        this.authenticationDAO = authenticationDAO;
    }




    /*
     * (non-Javadoc)
     * @see com.dmotorworks.vehicleinventory.dse.image.dataloader.service.AuthenticationService#authenticateSource(java.lang.String, java.lang.String)
     * 
     * This service is called from web service to authenticate the source id and password of the input request
     * 
     */
    public boolean authenticateSource(String sourceID, String sourcePass) throws Exception
    {
        
        log.debug(CLASS_NAME + ": ENTRY : authenticateSource()");
        
        return authenticationDAO.authenticateSource(sourceID, sourcePass);
        
        
    }
}
