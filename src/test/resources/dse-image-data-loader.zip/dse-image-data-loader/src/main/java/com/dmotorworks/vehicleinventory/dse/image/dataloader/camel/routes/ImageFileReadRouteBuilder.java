package com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.routes;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

import com.dmotorworks.vehicleinventory.dse.image.common.util.ImageConstants;

/**
 * @author tuhing
 *
 */
public class ImageFileReadRouteBuilder extends RouteBuilder {

    private final String CLASS_NAME = ImageFileReadRouteBuilder.class.getName();
    
    /*
     * bean injected values
     */
    public String baseInputDirectory;
    public String processingDirectory;
    public String processedDirectory;
    
    public String delayFactor;
    public int tokenize;
    public int throttle;
    public int throttleDelay;
    
    public String readLockCheckInterval;
    
    




    //constants
    private final String SOURCE_NAME = "SOURCE_NAME";
    private final String OPERATION_NAME = "OPERATION_NAME";
    private final String OPERATION_NAME_BATCH = "IMAGE_BATCH_LOAD";
    private final String SOURCE_NAME_DS = "DS";
    private final String ROUTE_FILE_READ = "dse-image.ROUTE_PROCESSING_FILE_READ";
    
    
    /*
     * (non-Javadoc)
     * @see org.apache.camel.builder.RouteBuilder#configure()
     * 
     * This route is used to read the accepted format file from base directory and load the contents into the queue
     * so that they can be processed and loaded into DB.
     */

    @SuppressWarnings("restriction")
    @Override
    public void configure() throws Exception {

        onException(Throwable.class)
            //.logStackTrace(true)
            .to("log:" + CLASS_NAME + exceptionMessage() +"?level=ERROR&showAll=true")
            .handled(true)
        ;
        
        
        /* 
         * route for reading the file - read the file, split and queue the message into activemq:queue:LOAD_FILE_DATA for processing
         */
        
        from("file:"+processingDirectory+"?readLock=changed&readLockCheckInterval="+readLockCheckInterval)
        .routeId(ROUTE_FILE_READ)
        .process(new Processor() {
            public void process(Exchange exchange) throws Exception {

                String fileNameOnly = (String)exchange.getIn().getHeader(Exchange.FILE_NAME_ONLY);
                String sourceName = new String();
               
                if(null != fileNameOnly){
                    
                    sourceName = fileNameOnly.substring(0,fileNameOnly.lastIndexOf("-") );
                }

                                
                exchange.getIn().setHeader(ImageConstants.OPERATION_NAME.getValue(), OPERATION_NAME_BATCH);
                exchange.getIn().setHeader(ImageConstants.SOURCE_NAME.getValue(), sourceName);
                
                exchange.setProperty(ImageConstants.OPERATION_NAME.getValue(), OPERATION_NAME_BATCH);
                exchange.setProperty(ImageConstants.SOURCE_NAME.getValue(), sourceName);

            }
            })
            .split().tokenize("\n", tokenize).streaming()
            .throttle(throttle).timePeriodMillis(throttleDelay)
            .inOnly("activemq:queue:LOAD_FILE_DATA")
       .to("file:"+processedDirectory+"?fileName=${file:name}"+"&fileExist=Append&flatten=true")
       ;

    }
    
    


    public String getBaseInputDirectory() {
        return baseInputDirectory;
    }

    public void setBaseInputDirectory(String baseInputDirectory) {
        this.baseInputDirectory = baseInputDirectory;
    }
    public String getProcessingDirectory() {
        return processingDirectory;
    }

    public void setProcessingDirectory(String processingDirectory) {
        this.processingDirectory = processingDirectory;
    }


    public String getProcessedDirectory() {
        return processedDirectory;
    }

    public void setProcessedDirectory(String processedDirectory) {
        this.processedDirectory = processedDirectory;
    }

    public String getReadLockCheckInterval() {
        return readLockCheckInterval;
    }

    public void setReadLockCheckInterval(String readLockCheckInterval) {
        this.readLockCheckInterval = readLockCheckInterval;
    }

     public String getDelayFactor() {
        return delayFactor;
    }

    public void setDelayFactor(String delayFactor) {
        this.delayFactor = delayFactor;
    }


    public int getTokenize() {
        return tokenize;
    }


    public void setTokenize(int tokenize) {
        this.tokenize = tokenize;
    }


    public int getThrottle() {
        return throttle;
    }


    public void setThrottle(int throttle) {
        this.throttle = throttle;
    }


    public int getThrottleDelay() {
        return throttleDelay;
    }


    public void setThrottleDelay(int throttleDelay) {
        this.throttleDelay = throttleDelay;
    }





}
