package com.dmotorworks.vehicleinventory.dse.test;

import java.util.Arrays;
import java.util.Date;
import java.util.Set;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.camel.CamelContext;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;

import com.dmotorworks.vehicleinventory.dse.image.dataloader.camel.routes.ImageFileLoadRouteBuilder;

public class ImageLoadTest {
    
    static Date t1;
    static Date t2;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
	    System.out.println("main thread "+Thread.currentThread().getName() );
		
	    //testFileCopy();
		//testjms();
	   // testrouting();
	   // testNewBuilderRoute();
	 //   testFileSplitterRoute();
	    testBeanIO();
	}
	

     /* private static void testFileSplitterRoute(){
           
           System.out.println("testNewBuilderRoute thread "+Thread.currentThread().getName() );
           // TODO Auto-generated method stub
           
           try {
               ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("vm://localhost");
               CamelContext context = new DefaultCamelContext();
               context.removeComponent("jms");
               context.addComponent("jms", JmsComponent.jmsComponentAutoAcknowledge(connectionFactory));
                              
               context.addRoutes(new ImageFileLoadRouteBuilder());
               
              // Thread.sleep(10000);
               //t1 = new Date();
               System.out.println("Now Start..");
               context.start();
               Thread.sleep(50000);
             //  printThreads();
               context.stop();
               
               //t2 = new Date();
               //long diff = t2.getTime() - t1.getTime();
               //System.out.println("Diff Time in Sec "+ diff/1000 );
               System.out.println("...Complete");
           } catch (Exception e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
           }
       
       }*/
      
      private static void testBeanIO(){
          
          System.out.println("testBeanIO thread "+Thread.currentThread().getName() );
          // TODO Auto-generated method stub
          
          try {
              ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("vm://localhost");
              CamelContext context = new DefaultCamelContext();
              context.removeComponent("activemq");
              context.addComponent("activemq", JmsComponent.jmsComponentAutoAcknowledge(connectionFactory));
                             
              context.addRoutes(new ImageFileLoadRouteBuilder());
              
             // Thread.sleep(10000);
              //t1 = new Date();
              System.out.println("Now Start..");
              context.start();
              Thread.sleep(500000);
            //  printThreads();
              context.stop();
              
              //t2 = new Date();
              //long diff = t2.getTime() - t1.getTime();
              //System.out.println("Diff Time in Sec "+ diff/1000 );
              System.out.println("...Complete");
          } catch (Exception e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
      
      }


       public static void printThreads(){
           Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
           Thread[] threadArray = threadSet.toArray(new Thread[threadSet.size()]);
           System.out.println(Arrays.toString(threadArray));

       }
       
}
